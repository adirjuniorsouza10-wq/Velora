#!/bin/bash
# Script para enviar o VELORA para o seu GitHub
# Uso: ./push-to-github.sh SEU_GITHUB_TOKEN

TOKEN=$1

if [ -z "$TOKEN" ]; then
  echo "Uso: ./push-to-github.sh SEU_GITHUB_TOKEN"
  echo "Exemplo: ./push-to-github.sh ghp_xxxxxxxxxxxxxxxxxxxx"
  exit 1
fi

git remote set-url origin https://adirjuniorsouza10-wq:${TOKEN}@github.com/adirjuniorsouza10-wq/Velora.git
git push -u origin main --force

echo "Projeto VELORA enviado com sucesso para https://github.com/adirjuniorsouza10-wq/Velora !"
