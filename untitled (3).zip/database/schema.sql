-- ============================================================================
-- VELORA SAAS — SCHEMA DE BANCO DE DADOS POSTGRESQL / SUPABASE
-- Sistema Operacional & Gestão para Barbearias de Alto Padrão
-- Multi-Tenant com Isolamento Rigoroso (RLS - Row Level Security)
-- ============================================================================

-- 1. EXTENSÕES POSTGRESQL
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 2. TABELA: TENANTS (ESTABELECIMENTOS / BARBEARIAS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS tenants (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    trade_name VARCHAR(255),
    document_cnpj VARCHAR(20),
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    address TEXT NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    booking_url VARCHAR(255) UNIQUE NOT NULL,
    logo_url TEXT,
    cover_image_url TEXT,
    theme_palette VARCHAR(30) DEFAULT 'teal',
    rating NUMERIC(3,2) DEFAULT 5.00,
    review_count INTEGER DEFAULT 0,
    currency_code VARCHAR(10) DEFAULT 'BRL',
    plan_tier VARCHAR(30) DEFAULT 'premium',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 3. TABELA: BRANCHES (UNIDADES / FILIAIS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS branches (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(30) NOT NULL,
    is_main_branch BOOLEAN DEFAULT FALSE,
    working_hours JSONB DEFAULT '{"mon_fri": "09:00 - 20:00", "sat": "08:30 - 19:30", "sun": "closed"}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 4. TABELA: STAFF (BARBEIROS, ESPECIALISTAS & RECEPÇÃO)
-- ============================================================================
CREATE TABLE IF NOT EXISTS staff (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    auth_user_id UUID, -- Vinculado a auth.users no Supabase
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(30) NOT NULL,
    role VARCHAR(30) NOT NULL CHECK (role IN ('owner', 'barber', 'receptionist', 'admin')),
    commission_rate NUMERIC(5,2) NOT NULL DEFAULT 50.00,
    specialties TEXT[] DEFAULT ARRAY['Corte Moderno', 'Barba']::TEXT[],
    avatar_url TEXT,
    rating NUMERIC(3,2) DEFAULT 5.00,
    completed_appointments_count INTEGER DEFAULT 0,
    color_tag VARCHAR(30) DEFAULT '#0d9488',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 5. TABELA: SERVICE CATEGORIES & SERVICES (CATÁLOGO DE SERVIÇOS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS service_categories (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS services (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    category_id VARCHAR(64) REFERENCES service_categories(id) ON DELETE SET NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    duration_minutes INTEGER NOT NULL DEFAULT 30,
    price_in_cents INTEGER NOT NULL CHECK (price_in_cents >= 0),
    custom_commission_rate NUMERIC(5,2),
    online_booking_enabled BOOLEAN DEFAULT TRUE,
    requires_deposit BOOLEAN DEFAULT FALSE,
    deposit_percentage NUMERIC(5,2) DEFAULT 0,
    badge VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 6. TABELA: CUSTOMERS & CRM
-- ============================================================================
CREATE TABLE IF NOT EXISTS customers (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(255),
    document_cpf VARCHAR(20),
    is_vip BOOLEAN DEFAULT FALSE,
    preferences TEXT,
    internal_notes TEXT,
    tags TEXT[] DEFAULT ARRAY['Cliente']::TEXT[],
    first_visit_date DATE,
    last_visit_date DATE,
    total_spent_in_cents BIGINT DEFAULT 0,
    appointments_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 7. TABELA: APPOINTMENTS (AGENDAMENTOS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS appointments (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    customer_email VARCHAR(255),
    professional_id VARCHAR(64) NOT NULL REFERENCES staff(id) ON DELETE RESTRICT,
    professional_name VARCHAR(255) NOT NULL,
    service_id VARCHAR(64) NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
    service_name VARCHAR(255) NOT NULL,
    price_in_cents INTEGER NOT NULL,
    duration_minutes INTEGER NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(30) NOT NULL CHECK (status IN ('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show')),
    payment_status VARCHAR(30) NOT NULL CHECK (payment_status IN ('pending', 'deposit_paid', 'paid', 'refunded')),
    payment_method VARCHAR(30) CHECK (payment_method IN ('pix', 'credit_card', 'debit_card', 'cash', 'velora_pass')),
    source VARCHAR(30) DEFAULT 'online' CHECK (source IN ('online', 'reception', 'whatsapp', 'walk_in')),
    notes TEXT,
    is_waitlist_fitted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 8. TABELA: WAITLIST (LISTA DE ESPERA INTELIGENTE)
-- ============================================================================
CREATE TABLE IF NOT EXISTS waitlist_entries (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    customer_id VARCHAR(64) REFERENCES customers(id) ON DELETE SET NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    service_id VARCHAR(64) REFERENCES services(id) ON DELETE SET NULL,
    service_name VARCHAR(255) NOT NULL,
    preferred_barber_id VARCHAR(64) REFERENCES staff(id) ON DELETE SET NULL,
    preferred_time VARCHAR(100),
    notes TEXT,
    status VARCHAR(30) DEFAULT 'waiting' CHECK (status IN ('waiting', 'notified', 'fitted', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 9. TABELA: CLUB PLANS & MEMBERS (VELORA CLUB - ASSINATURAS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS club_plans (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    tagline TEXT,
    monthly_price_in_cents INTEGER NOT NULL,
    max_appointments_per_month INTEGER NOT NULL DEFAULT 4,
    services_included TEXT[] NOT NULL,
    discount_on_products_percent NUMERIC(5,2) DEFAULT 10.00,
    badge VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS club_members (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    customer_id VARCHAR(64) NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    plan_id VARCHAR(64) NOT NULL REFERENCES club_plans(id) ON DELETE RESTRICT,
    plan_name VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending_payment', 'suspended', 'cancelled')),
    since_date DATE NOT NULL,
    next_renewal_date DATE NOT NULL,
    used_appointments_this_month INTEGER DEFAULT 0,
    limit_appointments_this_month INTEGER NOT NULL,
    payment_method VARCHAR(30) DEFAULT 'pix_recorrente' CHECK (payment_method IN ('pix_recorrente', 'credit_card')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 10. TABELA: CASH SESSIONS (SESSÕES DE CAIXA DIÁRIO)
-- ============================================================================
CREATE TABLE IF NOT EXISTS cash_sessions (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    opened_by_staff_id VARCHAR(64) NOT NULL REFERENCES staff(id) ON DELETE RESTRICT,
    opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ,
    initial_amount_in_cents INTEGER NOT NULL DEFAULT 0,
    current_amount_in_cents INTEGER NOT NULL DEFAULT 0,
    closing_amount_in_cents INTEGER,
    difference_in_cents INTEGER DEFAULT 0,
    notes TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 11. TABELA: FINANCIAL TRANSACTIONS (FLUXO FINANCEIRO & REPASSES)
-- ============================================================================
CREATE TABLE IF NOT EXISTS financial_transactions (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    cash_session_id VARCHAR(64) REFERENCES cash_sessions(id) ON DELETE SET NULL,
    appointment_id VARCHAR(64) REFERENCES appointments(id) ON DELETE SET NULL,
    customer_id VARCHAR(64) REFERENCES customers(id) ON DELETE SET NULL,
    staff_id VARCHAR(64) REFERENCES staff(id) ON DELETE SET NULL,
    type VARCHAR(30) NOT NULL CHECK (type IN ('income', 'expense', 'commission_payout', 'club_fee')),
    category VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    amount_in_cents INTEGER NOT NULL CHECK (amount_in_cents >= 0),
    payment_method VARCHAR(30) NOT NULL CHECK (payment_method IN ('pix', 'credit_card', 'debit_card', 'cash', 'bank_transfer')),
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 12. TABELA: INVENTORY (ESTOQUE & PRODUTOS REVENDIDOS)
-- ============================================================================
CREATE TABLE IF NOT EXISTS inventory_items (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('styling', 'care', 'supplies', 'beverage')),
    sku VARCHAR(100),
    current_stock INTEGER NOT NULL DEFAULT 0 CHECK (current_stock >= 0),
    min_stock INTEGER NOT NULL DEFAULT 5 CHECK (min_stock >= 0),
    cost_price_in_cents INTEGER NOT NULL CHECK (cost_price_in_cents >= 0),
    sale_price_in_cents INTEGER NOT NULL CHECK (sale_price_in_cents >= 0),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- 13. ÍNDICES DE ALTA PERFORMANCE (QUERY OPTIMIZATION)
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_appointments_tenant_date ON appointments (tenant_id, date);
CREATE INDEX IF NOT EXISTS idx_appointments_tenant_staff ON appointments (tenant_id, professional_id, date);
CREATE INDEX IF NOT EXISTS idx_appointments_tenant_customer ON appointments (tenant_id, customer_id);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_customers_tenant_phone ON customers (tenant_id, phone);
CREATE INDEX IF NOT EXISTS idx_transactions_tenant_date ON financial_transactions (tenant_id, date);
CREATE INDEX IF NOT EXISTS idx_staff_tenant ON staff (tenant_id, is_active);
CREATE INDEX IF NOT EXISTS idx_club_members_tenant_status ON club_members (tenant_id, status);

-- ============================================================================
-- 14. ROW LEVEL SECURITY (RLS) & POLÍTICAS DE ISOLAMENTO MULTI-TENANT
-- ============================================================================
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE waitlist_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE club_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE club_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE cash_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;

-- Exemplo de política de isolamento por Tenant ID extraído do token JWT:
-- (auth.jwt() ->> 'tenant_id')
CREATE POLICY tenant_isolation_appointments ON appointments
    FOR ALL
    USING (
        tenant_id = COALESCE(
            current_setting('request.jwt.claim.tenant_id', true),
            (auth.jwt() ->> 'tenant_id')
        )
    );

CREATE POLICY tenant_isolation_customers ON customers
    FOR ALL
    USING (
        tenant_id = COALESCE(
            current_setting('request.jwt.claim.tenant_id', true),
            (auth.jwt() ->> 'tenant_id')
        )
    );

CREATE POLICY tenant_isolation_finances ON financial_transactions
    FOR ALL
    USING (
        tenant_id = COALESCE(
            current_setting('request.jwt.claim.tenant_id', true),
            (auth.jwt() ->> 'tenant_id')
        )
    );

-- Política pública para agendamento online anônimo (leitura de serviços e horários disponíveis)
CREATE POLICY public_services_read ON services
    FOR SELECT
    USING (is_active = true);

CREATE POLICY public_staff_read ON staff
    FOR SELECT
    USING (is_active = true);

-- ============================================================================
-- 15. DADOS INICIAIS (SEED: BACKOUT BARBEARIA • TENANT-IAGO)
-- ============================================================================
INSERT INTO tenants (id, name, trade_name, email, phone, address, slug, booking_url, theme_palette, rating, review_count)
VALUES (
    'tenant-iago',
    'Backout Barbearia',
    'Backout Studio & Barber',
    'contato@backoutbarbearia.com.br',
    '(11) 98833-2211',
    'Rua das Palmeiras, 420 - Centro',
    'backout',
    'velora.app/backout',
    'teal',
    4.96,
    184
) ON CONFLICT (id) DO NOTHING;

INSERT INTO branches (id, tenant_id, name, address, phone, is_main_branch)
VALUES (
    'branch-iago-main',
    'tenant-iago',
    'Unidade Matriz - Centro',
    'Rua das Palmeiras, 420 - Centro',
    '(11) 98833-2211',
    true
) ON CONFLICT (id) DO NOTHING;

INSERT INTO staff (id, tenant_id, branch_id, name, phone, role, commission_rate, specialties, avatar_url, rating, completed_appointments_count)
VALUES 
    ('staff-iago-master', 'tenant-iago', 'branch-iago-main', 'Iago Barber (Fundador)', '(11) 98833-2211', 'owner', 65.00, ARRAY['Degradê Clássico', 'Barba Terapêutica', 'Visagismo'], 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80', 5.0, 342),
    ('staff-lucas-fade', 'tenant-iago', 'branch-iago-main', 'Lucas Barbeiro', '(11) 97711-4433', 'barber', 50.00, ARRAY['Fade Navalhado', 'Cabelo & Barba Combo', 'Sobrancelha'], 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80', 4.9, 198)
ON CONFLICT (id) DO NOTHING;

INSERT INTO services (id, tenant_id, name, description, duration_minutes, price_in_cents, custom_commission_rate, badge)
VALUES
    ('srv-corte', 'tenant-iago', 'Corte', 'Corte personalizado com visagismo, tesoura e máquina + lavagem', 35, 3500, 50.00, 'Mais Popular'),
    ('srv-barba', 'tenant-iago', 'Barba', 'Toalha quente, navalha descartável, massagem facial e alinhamento', 30, 3000, 50.00, NULL),
    ('srv-combo', 'tenant-iago', 'Corte & Barba Completo', 'Experiência completa com visagismo, toalha quente e pós-barba', 55, 6000, 50.00, 'Recomendado')
ON CONFLICT (id) DO NOTHING;

INSERT INTO club_plans (id, tenant_id, name, tagline, monthly_price_in_cents, max_appointments_per_month, services_included, discount_on_products_percent, badge)
VALUES
    ('plan-cabelo', 'tenant-iago', 'Plano Cabelo', 'Cortes ilimitados ou semanais para manter o visual impecável o mês inteiro', 8000, 4, ARRAY['Corte de Cabelo Ilimitado no Mês', 'Lavagem e Finalização Pomada'], 10.00, 'Assinatura Popular'),
    ('plan-barba', 'tenant-iago', 'Plano Barba', 'Alinhamento constante, toalha quente e óleo hidratante toda semana', 12000, 4, ARRAY['Barboterapia Completa Semanal', 'Toalha Quente e Pós-Barba Premium'], 15.00, 'VIP Barba')
ON CONFLICT (id) DO NOTHING;
