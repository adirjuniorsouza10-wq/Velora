import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ 
  className = '', 
  size = 'md',
  showSubtitle = true 
}) => {
  const iconSizes = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-8 h-8 text-sm',
    lg: 'w-10 h-10 text-base'
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-base font-bold',
    lg: 'text-xl font-bold'
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Minimalist Monogram Icon with Precision Teal Accent */}
      <div className={`relative ${iconSizes[size]} rounded-lg bg-slate-900 dark:bg-white flex items-center justify-center font-bold text-white dark:text-slate-950 shrink-0 shadow-xs border border-slate-800 dark:border-slate-200`}>
        <svg 
          viewBox="0 0 24 24" 
          fill="none" 
          className="w-4 h-4 text-teal-400 dark:text-teal-600"
        >
          <path 
            d="M4 5L12 20L20 5H15.5L12 13.5L8.5 5H4Z" 
            fill="currentColor" 
          />
          <circle cx="12" cy="4" r="1.5" fill="#0D9488" />
        </svg>
      </div>

      {/* Brand Name & Typography */}
      <div className="leading-none">
        <div className="flex items-center gap-1.5">
          <span className={`font-extrabold tracking-tight text-slate-900 dark:text-white ${textSizes[size]}`}>
            VELORA
          </span>
          <span className="text-[10px] font-semibold tracking-wider text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 px-1.5 py-0.5 rounded">
            OS
          </span>
        </div>
        {showSubtitle && (
          <p className="text-[10px] font-medium tracking-wide text-slate-500 dark:text-slate-400 mt-0.5">
            Barbershop Management
          </p>
        )}
      </div>
    </div>
  );
};
