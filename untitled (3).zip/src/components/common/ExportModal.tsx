import React, { useState } from 'react';
import { 
  Download, 
  Github, 
  Check, 
  Copy, 
  ExternalLink, 
  X, 
  Terminal, 
  ShieldCheck, 
  GitBranch, 
  FileCode2,
  Sparkles
} from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [token, setToken] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedGitCommand, setCopiedGitCommand] = useState(false);

  if (!isOpen) return null;

  const repoUrl = 'https://github.com/adirjuniorsouza10-wq/Velora.git';
  const effectiveToken = token.trim() || 'SEU_GITHUB_TOKEN';
  const pushScriptCmd = `./push-to-github.sh ${effectiveToken}`;
  const directGitCmd = `git remote set-url origin https://adirjuniorsouza10-wq:${effectiveToken}@github.com/adirjuniorsouza10-wq/Velora.git && git push -u origin main --force`;

  const copyToClipboard = (text: string, type: 'script' | 'git') => {
    navigator.clipboard.writeText(text);
    if (type === 'script') {
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2500);
    } else {
      setCopiedGitCommand(true);
      setTimeout(() => setCopiedGitCommand(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl animate-in fade-in zoom-in-95 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-900 dark:bg-teal-600 text-white">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Exportar Código &amp; Sincronização GitHub
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Baixe o pacote completo ou envie os commits para o seu repositório oficial
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Option 1: Baixar Arquivo Completo */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-zinc-200">
              <FileCode2 className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Opção 1: Download Direto do Código Fonte</span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">8.8 MB (.tar.gz)</span>
          </div>

          <p className="text-xs text-slate-600 dark:text-zinc-400 leading-relaxed">
            Pacote completo com todos os 57+ arquivos do projeto, TypeScript, Vite, Tailwind CSS v4, gráficos Recharts e histórico Git.
          </p>

          <a
            href="/velora-export.tar.gz"
            download="velora-barbearia-completo.tar.gz"
            className="w-full py-2.5 px-4 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Baixar Projeto Completo (.tar.gz)</span>
          </a>
        </div>

        {/* Option 2: Sincronizar com GitHub */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-zinc-200">
              <GitBranch className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>Opção 2: Enviar para seu Repositório GitHub</span>
            </div>
            <a
              href={repoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-teal-700 dark:text-teal-400 font-semibold flex items-center gap-1 hover:underline"
            >
              <span>Abrir Repositório</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-700 dark:text-zinc-300 block">
              Seu Personal Access Token do GitHub (Classic com permissão 'repo'):
            </label>
            <input
              type="password"
              placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              value={token}
              onChange={e => setToken(e.target.value)}
              className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-xl text-slate-900 dark:text-white text-xs font-mono outline-none focus:border-teal-600"
            />
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-semibold text-slate-600 dark:text-zinc-400 flex items-center justify-between">
              <span>Comando pronto para executar no terminal:</span>
              <button
                onClick={() => copyToClipboard(pushScriptCmd, 'script')}
                className="text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
              >
                {copiedScript ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copiedScript ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>

            <div className="bg-slate-900 text-slate-100 p-2.5 rounded-lg text-xs font-mono overflow-x-auto flex items-center justify-between gap-2 border border-slate-800">
              <span className="truncate">{pushScriptCmd}</span>
              <button
                onClick={() => copyToClipboard(pushScriptCmd, 'script')}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
                title="Copiar comando"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] font-semibold text-slate-600 dark:text-zinc-400 flex items-center justify-between">
              <span>Ou comando Git nativo completo:</span>
              <button
                onClick={() => copyToClipboard(directGitCmd, 'git')}
                className="text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
              >
                {copiedGitCommand ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copiedGitCommand ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>

            <div className="bg-slate-900 text-slate-100 p-2.5 rounded-lg text-[11px] font-mono overflow-x-auto flex items-center justify-between gap-2 border border-slate-800">
              <span className="truncate">{directGitCmd}</span>
              <button
                onClick={() => copyToClipboard(directGitCmd, 'git')}
                className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
                title="Copiar comando git"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-zinc-800 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-zinc-400 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Repositório configurado na branch <strong>main</strong></span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-200 rounded-xl font-semibold transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
